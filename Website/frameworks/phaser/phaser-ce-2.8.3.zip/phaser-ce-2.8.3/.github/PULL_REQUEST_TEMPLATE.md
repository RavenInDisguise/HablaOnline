Make sure you describe your PR in the [README Change Log](https://github.com/photonstorm/phaser-ce/blob/master/README.md#change-log) section!

This PR changes (✏️ delete as applicable)

* Documentation
* TypeScript Defs
* The public-facing API
* Nothing, it's a bug fix

Describe the changes below:
